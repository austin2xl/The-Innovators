// Fetch NCR data from the JSON file
async function fetchNCRData() {
    try {
        const response = await fetch('data.json'); // Ensure this file is in the same directory
        const data = await response.json();
        return data.NCR.filter(ncr => ncr.PurchasingStatus == "Pending" && ncr.Status == "Open"); // Filter NCRs processed through Purchasing
    } catch (error) {
        console.error('Error fetching NCR data:', error);
        return [];
    }
}

// Fetch notifications from the JSON file async function fetchNotifications(role)
 { try { const response = await fetch('notifications.json'); // Ensure this file is in the same directory
  const data = await response.json(); return data.Notifications.filter(notification => notification.Role === role && notification.Status === "unread"); }
   catch (error) { console.error('Error fetching notifications:', error); return []; } }


// Render NCR data into the table
async function renderNCRTable() {
    const ncrs = await fetchNCRData();
    const tableBody = document.querySelector('#ncr-table tbody');

    tableBody.innerHTML = ''; // Clear existing rows

    if (ncrs.length === 0) {
        const noDataRow = document.createElement('tr');
        noDataRow.innerHTML = `<td colspan="6">No processed NCRs found.</td>`;
        tableBody.appendChild(noDataRow);
        return;
    }

    ncrs.forEach(ncr => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${ncr.NCRNumber}</td>
            <td>${ncr.Description}</td>
            <td>${ncr.Status}</td>
            <td>${ncr.Priority}</td>
            <td>${ncr.QualityReview}</td>
            <td>${ncr.PurchasingStatus}</td>
        `;
        tableBody.appendChild(row);
    });
}

// Apply filters and re-render the table
async function applyFilters() {
    const ncrs = await fetchNCRData();

    const statusFilter = document.getElementById('status-filter').value;
    const priorityFilter = document.getElementById('priority-filter').value;
    const dateFilter = document.getElementById('date-filter').value;

    const filteredNCRs = ncrs.filter(ncr => {
        const matchesStatus = statusFilter == 'all' || ncr.Status == statusFilter;
        const matchesPriority = priorityFilter == 'all' || ncr.Priority == priorityFilter;
        const matchesDate = !dateFilter || ncr.CreatedDate == dateFilter;
        return matchesStatus && matchesPriority && matchesDate;
    });

    renderNCRTable(filteredNCRs);
}

// Function to add notifications
function addNotification(message) {
    const mailList = document.getElementById('mailList');
    const mailListOne = document.getElementById('mailList-one');
    const notification = document.createElement('li');
    notification.textContent = message;
    mailList.appendChild(notification);
    mailListOne.appendChild(notification.cloneNode(true));
}

// Function to notify quality inspectors and purchasing about NCRs
async function notifyActionsNeeded() {
    const ncrs = await fetchNCRData();
    ncrs.forEach(ncr => {
        addNotification(`Quality inspector action needed on NCR-${ncr.NCRNumber}`);
        addNotification(`Purchasing action needed on NCR-${ncr.NCRNumber}`);
    });

    // Indicate unread notifications
    const notificationBell = document.querySelector('.notification-bell');
    const notificationBellOne = document.querySelector('.notification-bell-one');
    notificationBell.classList.add('has-unread');
    notificationBellOne.classList.add('has-unread');
}

// Initialize dashboard
async function initDashboard() {
    const ncrs = await fetchNCRData();
    renderNCRTable(ncrs);

    document.getElementById('filter-btn').addEventListener('click', applyFilters);

    // Notify quality inspectors and purchasing on dashboard initialization
    notifyActionsNeeded();
}

// Run initialization
initDashboard();
