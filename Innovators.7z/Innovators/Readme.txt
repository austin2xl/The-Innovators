e# Prog-1180 - Fall 2024

Site: [Crossfire NCR App](https://github.com/austin2xl/The-Innovators)

- Manish Kumar
- Tania
- Begoude Rikong Emmanuel Austeen
- Chibueze Abraham
-Shahbaaz
